using SQLite;
using System.Collections.Generic;
using System.Threading.Tasks;

public class DatabaseService
{
    readonly SQLiteAsyncConnection db;
    public DatabaseService(string path)
    {
        db = new SQLiteAsyncConnection(path);
        db.CreateTableAsync<UserLocation>().Wait();
    }
    public Task<int> SaveAsync(UserLocation loc) => db.InsertAsync(loc);
    public Task<List<UserLocation>> GetAllAsync() => db.Table<UserLocation>().ToListAsync();
}
