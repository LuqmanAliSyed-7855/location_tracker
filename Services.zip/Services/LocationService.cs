using Microsoft.Maui.Devices.Sensors;
using System.Threading.Tasks;

public class LocationService
{
    public async Task<Location> GetCurrentAsync()
    {
        var request = new GeolocationRequest(GeolocationAccuracy.Medium);
        return await Geolocation.Default.GetLocationAsync(request);
    }
}
